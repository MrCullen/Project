﻿<?php
return array(
	//'配置项'=>'配置值'
	'DB_PREFIX'=>'tp_',
	'DB_DSN'=>'mysql://wenbo_admin:twb1234@localhost:3306/wenbo_child',
	define('APP_DEBUG', true),
	'SESSION_AUTO_START' =>true,
);
?>