<?php
define('APP_DEBUG',TRUE); // ��������ģʽ
define('DB_FIELD_CACHE',false);
define('HTML_CACHE_ON',false);
define('APP_NAME','Admin');
define('APP_PATH','./Admin/');
require './ThinkPHP/ThinkPHP.php';

?>