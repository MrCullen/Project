<?php
return array(
	//'配置项'=>'配置值'
	'DB_PREFIX'=>'tp_',
	'DB_DSN'=>'mysql://root:1234@localhost:3306/db_child',
	define('APP_DEBUG', true),
	'SESSION_AUTO_START' =>true,
);
?>